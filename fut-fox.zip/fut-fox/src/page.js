window.__FUT_GALLERY_EXT = true;
(function () {
  var BACKEND = 'https://fut-gallery-planner-production.up.railway.app';
  fetch(BACKEND + '/gallery.js')
    .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
    .then(eval)
    .catch(function (e) {
      console.error('[FUT Fox] could not load from ' + BACKEND + ': ' + e.message);
    });
})();
