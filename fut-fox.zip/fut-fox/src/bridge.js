/*
 * Bridge between the web app page and the extension.
 *
 * The buyer panel and the planner have to run in the page's own world, or they
 * cannot see the app's fetch and XMLHttpRequest. Nothing in that world can
 * reach the extension's storage or chrome.runtime, so their calls to our
 * backend hop through here to the service worker, which adds your sign-in.
 *
 * Two secrets, kept on opposite sides on purpose. EA's session lives in the
 * page, because every EA request has to go out from the web app itself. Our
 * sign-in token lives in the extension: the page only ever learns whether you
 * are signed in, and as whom. And only the backend calls and body fields named
 * below cross over, so nothing else the page holds can leak out through here.
 */

const TAG = 'fut-planner';

// Backend calls the page may make. GETs carry no body; each POST keeps only
// the fields listed for it -- anything else is dropped, not filtered, so a new
// field has to be added here on purpose.
const GETS = [
  /^\/gallery\/(overview|me|queue|set\?id=\d+)$/,
  /^\/sbc\/(sets|challenge\?id=\d+(&set=\d+)?|result\?id=[0-9a-f]{32})$/,
];
const POSTS = {
  '/gallery/plan': ['coins', 'owned', 'skip'],
  '/gallery/queue': ['setId', 'grade'],
  '/gallery/queue/mark': ['eaId', 'status', 'paid', 'listed'],
  '/gallery/queue/clear': [],
  // Five counts, a day at a time. Nothing about which cards.
  '/stats': ['searches', 'bought', 'missed', 'spent', 'profit'],
  // Your club goes up to be solved: card ids and attributes, nothing of EA's
  // session. The backend never talks to EA.
  '/sbc/solve': ['club', 'challengeId', 'setId', 'excludeActive', 'regularOnly', 'ignorePositions', 'buy', 'cheapest',
                 'exclude', 'timeout', 'slots'],
};

function clean(path, body) {
  if (body == null) return GETS.some((re) => re.test(path)) ? { path, body: null } : null;
  const keep = POSTS[path];
  if (!keep || typeof body !== 'object') return null;
  const out = {};
  for (const k of keep) {
    if (body[k] !== undefined) out[k] = body[k];
  }
  return { path, body: out };
}

function down(msg) {
  window.postMessage({ tag: TAG, dir: 'down', ...msg }, window.location.origin);
}

// The popup's settings, as the page needs them: known switches, true or false.
const SETTINGS = ['excludeActive', 'regularOnly', 'ignorePositions', 'buy', 'sell', 'sniper'];
function settingsFor(saved) {
  const out = {};
  for (const k of SETTINGS) {
    if (saved && typeof saved[k] === 'boolean') out[k] = saved[k];
  }
  return out;
}

async function tellAuth() {
  try {
    const { session, settings } = await chrome.storage.local.get(['session', 'settings']);
    down({
      auth: { signedIn: !!(session && session.token), email: (session && session.email) || null },
      settings: settingsFor(settings),
      icon: chrome.runtime.getURL('icons/icon48.png'),
    });
  } catch {
    // The extension was reloaded under this page; the page keeps its last word.
  }
}

window.addEventListener('message', (event) => {
  // Only this page, and only our own messages going up.
  if (event.source !== window) return;
  const msg = event.data;
  if (!msg || msg.tag !== TAG || msg.dir !== 'up') return;
  if (msg.hello) { tellAuth(); return; }
  if (!msg.id) return;

  const call = clean(String(msg.path || ''), msg.body);
  if (!call) { down({ id: msg.id, error: 'not allowed' }); return; }
  try {
    chrome.runtime.sendMessage({ kind: 'backend', path: call.path, body: call.body }, (reply) => {
      const error = chrome.runtime.lastError;
      if (error || !reply) {
        down({ id: msg.id, error: error ? error.message : 'no answer from the extension' });
        return;
      }
      down({ id: msg.id, status: reply.status, data: reply.data, error: reply.error || null });
    });
  } catch {
    down({ id: msg.id, error: 'the extension was updated - reload this page' });
  }
});

// Signing in or out, or changing a setting, in the popup reaches an open web
// app at once. A setting goes on its own: it must not look like a new sign-in.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.session) tellAuth();
  else if (changes.settings) down({ settings: settingsFor(changes.settings.newValue) });
});

tellAuth();
