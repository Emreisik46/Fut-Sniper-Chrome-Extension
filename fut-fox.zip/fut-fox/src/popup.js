/*
 * Sign-in and settings for the extension. The tools themselves are in the web
 * app: the Use Fox button on the SBC screen, the Planner page in EA's menu.
 * Settings come a category at a time -- SBC, Gallery, Account -- picked with
 * the buttons at the top.
 *
 * The password is posted to the backend and never stored; what comes back is
 * an opaque session token kept in extension storage, which the service worker
 * attaches to later calls. The web app page never sees either: it is told only
 * that you are signed in, and as whom (bridge.js) -- and your settings.
 */

const DEFAULT_BACKEND = 'https://fut-gallery-planner-production.up.railway.app';
const DEFAULT_SETTINGS = { excludeActive: true, regularOnly: false, ignorePositions: true, buy: true, sell: true, sniper: true };
const TABS = ['sbc', 'gallery', 'sniper', 'account'];

const $ = (id) => document.getElementById(id);
let noteTimer = 0;
const note = (text, bad) => {
  clearTimeout(noteTimer);
  $('note').textContent = text || '';
  $('note').classList.toggle('bad', !!bad);
  // A plain "saved" goes by itself; errors stay until the next thing happens.
  if (text && !bad) noteTimer = setTimeout(() => { $('note').textContent = ''; }, 1800);
};

async function backendUrl() {
  const { backend } = await chrome.storage.local.get('backend');
  return backend || DEFAULT_BACKEND;
}

async function post(path, body) {
  const base = await backendUrl();
  let res;
  try {
    res = await fetch(base + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  } catch (e) {
    // Nearly always the backend simply is not running.
    throw new Error('cannot reach ' + base);
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.ok === false) throw new Error(data.error || ('HTTP ' + res.status));
  return data;
}

// Where somebody with no account goes. Asked of the server rather than built
// in, so the link can change without everybody reinstalling -- and a server
// that has not been told one simply does not offer it.
async function showInvite() {
  const link = $('invite');
  if (!link) return;
  try {
    const res = await fetch(await backendUrl() + '/health');
    const { invite } = await res.json();
    if (!invite) return;
    link.href = invite;
    link.hidden = false;
    // The button says where to go, so the sentence under it is now noise.
    const line = $('no-account');
    if (line) line.hidden = true;
  } catch (e) { /* offline: the line still says to ask in Discord */ }
}

async function render() {
  const { session, backend, popupTab } = await chrome.storage.local.get(['session', 'backend', 'popupTab']);
  $('backend').value = backend || DEFAULT_BACKEND;
  const signedIn = !!(session && session.token);
  $('signed-out').hidden = signedIn;
  $('signed-in').hidden = !signedIn;
  // The server field lives with whichever view is showing -- and only on a
  // build pointed at this machine. A build for other people may reach exactly
  // one server (its host_permissions), so editing the address there cannot
  // work: it would silently break the extension and look like a bug.
  const selfHosted = /127\.0\.0\.1|localhost/.test(DEFAULT_BACKEND);
  if (!signedIn) showInvite();
  $('server-out').hidden = !selfHosted;
  $('server-in').hidden = !selfHosted;
  if (selfHosted) $(signedIn ? 'server-in' : 'server-out').appendChild($('server-box'));
  else $('server-box').hidden = true;
  if (signedIn) {
    $('who').textContent = session.email || 'you';
    showTab(TABS.includes(popupTab) ? popupTab : 'sbc');
    await renderSettings();
  }
  await checkWebApp(signedIn);
}

// --- the category buttons -----------------------------------------------------------
function showTab(tab) {
  for (const b of document.querySelectorAll('#tabs button')) b.classList.toggle('on', b.dataset.tab === tab);
  for (const p of document.querySelectorAll('[data-panel]')) p.hidden = p.dataset.panel !== tab;
}

for (const b of document.querySelectorAll('#tabs button')) {
  b.onclick = () => {
    showTab(b.dataset.tab);
    chrome.storage.local.set({ popupTab: b.dataset.tab });   // opens there next time
  };
}

// --- settings: each switch saves as it flips; an open web app follows at once ----------
async function renderSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  const s = { ...DEFAULT_SETTINGS, ...(settings || {}) };
  for (const box of document.querySelectorAll('input[data-setting]')) box.checked = !!s[box.dataset.setting];
}

for (const box of document.querySelectorAll('input[data-setting]')) {
  box.onchange = async () => {
    const { settings } = await chrome.storage.local.get('settings');
    await chrome.storage.local.set({
      settings: { ...DEFAULT_SETTINGS, ...(settings || {}), [box.dataset.setting]: box.checked },
    });
    note('Saved');
  };
}

// The extension only ever talks to EA from inside an open web app tab, using
// the session the app itself holds. Signed in with no web app open is the
// moment to say so -- tools that reach EA from anywhere else are what get
// accounts banned.
const WEB_APP = 'https://www.ea.com/ea-sports-fc/ultimate-team/web-app/';

async function checkWebApp(signedIn) {
  const tabs = await chrome.tabs.query({ url: 'https://www.ea.com/*/ultimate-team/web-app/*' });
  const open = tabs.length > 0;
  $('webapp').hidden = !signedIn;
  $('webapp').className = 'pill ' + (open ? 'ok' : 'bad');
  $('webapp').textContent = open ? 'Web app open' : 'Web app closed';
  $('closed').hidden = !signedIn || open;
}

$('open-webapp').onclick = () => chrome.tabs.create({ url: WEB_APP });

// --- account ---------------------------------------------------------------------------
async function authenticate(path) {
  const email = $('email').value.trim();
  const password = $('password').value;
  if (!email || !password) { note('Name and password, please.', true); return; }

  $('signin').disabled = true;
  note('');
  try {
    const data = await post(path, { email, password });
    await chrome.storage.local.set({ session: { token: data.token, email: data.email } });
    $('password').value = '';
    await render();
  } catch (e) {
    note(e.message, true);
  } finally {
    $('signin').disabled = false;
  }
}

$('signin').onclick = () => authenticate('/auth/login');
$('password').onkeydown = (e) => { if (e.key === 'Enter') authenticate('/auth/login'); };

$('signout').onclick = async () => {
  const { session } = await chrome.storage.local.get('session');
  // Tell the backend so the token stops working, but sign out locally even if
  // that call fails -- the user asked to be signed out.
  if (session && session.token) {
    post('/auth/logout', { token: session.token }).catch(() => {});
  }
  await chrome.storage.local.remove('session');
  note('Signed out');
  await render();
};

// Deleting an account takes its password as well as the sign-in, so a
// borrowed browser cannot wipe someone out.
$('delete-account').onclick = async () => {
  const { session } = await chrome.storage.local.get('session');
  const password = $('delete-password').value;
  if (!session || !password) { note('Type your password first.', true); return; }
  $('delete-account').disabled = true;
  try {
    const res = await fetch((await backendUrl()) + '/auth/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + session.token },
      body: JSON.stringify({ password }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) throw new Error(data.error || ('HTTP ' + res.status));
    await chrome.storage.local.remove('session');
    $('delete-password').value = '';
    note('Your account is deleted.');
    await render();
  } catch (e) {
    note(e.message, true);
  } finally {
    $('delete-account').disabled = false;
  }
};

$('privacy').onclick = async (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: (await backendUrl()) + '/app/privacy.html' });
};

$('backend').onchange = async () => {
  const value = $('backend').value.trim() || DEFAULT_BACKEND;
  await chrome.storage.local.set({ backend: value });
  note('Server set to ' + value);
};

render();
