/*
 * Service worker: the only part of the extension that talks to our backend.
 *
 * It holds the signed-in session token and adds it to each call the web app
 * page makes through bridge.js. The page never sees that token, and the backend
 * never sees EA's -- those two secrets stay on opposite sides of the bridge on
 * purpose. If this backend is ever breached, what leaks is card ids and
 * prices, not anyone's game account.
 */

const DEFAULT_BACKEND = 'https://fut-gallery-planner-production.up.railway.app';

// The same calls bridge.js lets through, checked again on the side that adds
// the token.
const GETS = [
  // A set, and -- when the page knows it -- how many coins you hold, which
  // decides which lineup it can answer with. A number and nothing else.
  /^\/gallery\/(overview|me|queue|set\?id=\d+(&coins=\d+)?)$/,
  // The challenge lookup carries what the game is showing, because fut.gg
  // refuses the server's address: same requirements, same wording.
  /^\/sbc\/(sets|challenge\?id=\d+(&set=\d+)?(&app=[^&]*)?|result\?id=[0-9a-f]{32})$/,
];
const POSTS = new Set(['/gallery/plan', '/gallery/queue', '/gallery/queue/mark', '/gallery/queue/clear',
  '/sbc/solve', '/stats']);

async function backendUrl() {
  const { backend } = await chrome.storage.local.get('backend');
  return backend || DEFAULT_BACKEND;
}

async function call(path, body) {
  if (body == null ? !GETS.some((re) => re.test(path)) : !POSTS.has(path)) return { error: 'not allowed' };
  const { session } = await chrome.storage.local.get('session');
  const headers = { 'Content-Type': 'application/json' };
  if (session && session.token) headers.Authorization = 'Bearer ' + session.token;

  let res;
  try {
    res = await fetch((await backendUrl()) + path, body == null
      ? { headers }
      : { method: 'POST', headers, body: JSON.stringify(body) });
  } catch {
    return { error: 'cannot reach the FUT Fox server' };
  }
  if (res.status === 401) {
    // The token expired or was revoked. Dropping it makes the popup ask again,
    // and bridge.js tells the open web app that you are signed out.
    await chrome.storage.local.remove('session');
  }
  return { status: res.status, data: await res.json().catch(() => ({})) };
}

chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (!msg || msg.kind !== 'backend') return false;
  call(msg.path, msg.body)
    .then(respond)
    .catch((e) => respond({ error: e.message }));
  return true;          // keep the channel open for the async reply
});
